<?php

return [
    [
        'key'   => 'download-customer-links',
        'name'  => 'AdBlue/DTC/DPF/EGR',
        'route' => 'download-customer-links.admin.index',
        'sort'  =>  5,
        'icon'  => 'icon-notification',
    ],
];