<?php

namespace Webkul\DownloadLinks\Contracts;

interface DownloadCustomerLink
{
}
