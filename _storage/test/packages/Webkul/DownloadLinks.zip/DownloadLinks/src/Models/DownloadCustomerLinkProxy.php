<?php

namespace Webkul\DownloadLinks\Models;

use Konekt\Concord\Proxies\ModelProxy;

class DownloadCustomerLinkProxy extends ModelProxy
{
}
