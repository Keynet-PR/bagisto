<li {{ $attributes->merge(['class' => 'px-5 py-2 text-base cursor-pointer hover:bg-gray-100']) }}>
    {{ $slot }}
</li>