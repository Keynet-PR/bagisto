<label {{ $attributes->merge(['class' => 'block mb-2 text-base']) }}>
    {{ $slot }}
</label>
