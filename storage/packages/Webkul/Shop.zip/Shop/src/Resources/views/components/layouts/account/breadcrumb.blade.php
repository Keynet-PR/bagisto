<div class="flex justify-start mt-8 max-lg:hidden">
    <div class="flex gap-x-3.5 items-center">
        @yield('breadcrumbs')
    </div>
</div>
