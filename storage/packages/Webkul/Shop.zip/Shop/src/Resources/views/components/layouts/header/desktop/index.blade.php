<div class="flex flex-wrap max-lg:hidden">
    <x-shop::layouts.header.desktop.bottom />
</div>
