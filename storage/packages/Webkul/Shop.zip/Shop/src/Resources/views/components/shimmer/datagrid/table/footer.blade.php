<div class="flex justify-between items-center p-6">
    <div class="shimmer w-40 h-[18px]"></div>

    <div>
        <ul class="inline-flex items-center -space-x-px">
            <div class="shimmer w-[35px] h-[30px]"></div>
            <div class="shimmer w-[35px] h-[30px]"></div>
            <div class="shimmer w-[35px] h-[30px]"></div>
        </ul>
    </div>
</div>