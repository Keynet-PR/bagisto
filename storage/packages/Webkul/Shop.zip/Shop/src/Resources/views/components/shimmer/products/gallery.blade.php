<div class="flex gap-8 max-1180:hidden h-max sticky top-8">
    <div class="flex gap-2.5 max-w-[100px] max-h-[100px] flex-wrap">
        <div class="flex-24 justify-center place-content-start h-509 flex gap-2.5 max-w-[100px] flex-wrap">
            <span class="shimmer w-6 h-6 text-2xl"></span>
            <div class="shimmer min-w-[100px] min-h-[100px] w-[100px] h-[100px] rounded-xl"></div>
            <div class="shimmer min-w-[100px] min-h-[100px] w-[100px] h-[100px] rounded-xl"></div>
            <div class="shimmer min-w-[100px] min-h-[100px] w-[100px] h-[100px] rounded-xl"></div>
            <div class="shimmer min-w-[100px] min-h-[100px] w-[100px] h-[100px] rounded-xl"></div>
            <div class="shimmer min-w-[100px] min-h-[100px] w-[100px] h-[100px] rounded-xl"></div>
            <span class="shimmer w-6 h-6 text-2xl"></span>
        </div>
    </div>
    
    <div class="max-h-[610px] max-w-[560px]">
        <div class="shimmer min-w-[560px] min-h-[607px] rounded-xl"></div>
    </div>
</div>