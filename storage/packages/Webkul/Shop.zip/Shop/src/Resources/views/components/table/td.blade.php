<td {{ $attributes->merge(['class' => 'table-data']) }}>
    {{ $slot }}
</td>